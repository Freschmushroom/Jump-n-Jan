package at.jumpandjan.levelcreator;

import static org.lwjgl.opengl.GL11.*;
import at.jumpandjan.TextureManager;

public class ObjectChooserSlotTrash extends ObjectChooserSlot {

	private int trashList;
	
	public ObjectChooserSlotTrash(double x, double y, double width,
			double height) {
		super(null, x, y, width, height);
	}

	public void render() {
		glPushMatrix();
		
		if (trashList == 0) {
			trashList = glGenLists(1);
			glNewList(trashList, GL_COMPILE);
			TextureManager.instance.bindTexture("/slot_trash.png");
			glEnable(GL_TEXTURE_2D);
			
			glBegin(GL_QUADS);
			
			glTexCoord2f(0, 0);
			glVertex2d(x, y);
			glTexCoord2f(0, 1);
			glVertex2d(x, y + height);
			glTexCoord2f(1, 1);
			glVertex2d(x + width, y + height);
			glTexCoord2f(1, 0);
			glVertex2d(x + width, y);
			
			glEnd();
			glDisable(GL_TEXTURE_2D);
			
			glEndList();
		}
		
		glCallList(trashList);
		
		glPopMatrix();
	}
}

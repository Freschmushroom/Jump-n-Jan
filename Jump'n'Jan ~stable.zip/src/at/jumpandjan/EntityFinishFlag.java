package at.jumpandjan;

import at.jumpandjan.level.Level;

import at.freschmushroom.Out;

public class EntityFinishFlag extends EntityFlag {
	public EntityFinishFlag(double x, double y, Level level) {
		super(x, y, "/Finish_Flag.png", level);
	}
	
	public EntityFinishFlag(double x, double y, double width, double height, Level level) {
		super(x, y, width, height, "/Finish_Flag.png", level);
	}

	@Override
	public void update() {
		super.update();
		if(collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.wooon();
		}
	}
	
	static {
		Out.inf(EntityFinishFlag.class, "22.10.12", "Felix", null);
	}
}

package at.jumpandjan;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;

public class User implements Serializable {
	private String name;

	private HashSet<String> unlockedLvls = new HashSet<String>();
	private HashMap<String, Integer> pointsPerLevel = new HashMap<String, Integer>();

	public User(String name) {
		setName(name);
		unlockLvl(Constants.getDEFAULT_LVL_NAME());
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void unlockLvl(String lvl) {
		unlockedLvls.add(lvl);
		pointsPerLevel.put(lvl, 0);
	}

	public void finishedLvl(String lvl, int achievedPoints) {
		pointsPerLevel.put(lvl, achievedPoints);
	}

	public void save() {
		try {
			ObjectOutputStream oos = new ObjectOutputStream(
					new FileOutputStream("saves/" + name + ".user"));
			
			oos.writeObject(this);
			
			oos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public boolean isUnlocked(String name) {
		return unlockedLvls.contains(name);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder("User: ");
		sb.append(name);
		sb.append("\n");
		sb.append("Unlocked levels:\r\n");
		for (String s : unlockedLvls) {
			sb.append('\t');
			sb.append(s);
			sb.append("\r\n");
		}
		
		return sb.toString();
	}
}

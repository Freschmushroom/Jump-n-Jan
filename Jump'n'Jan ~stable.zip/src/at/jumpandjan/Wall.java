package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glRotatef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;
import at.freschmushroom.Out;
import at.freschmushroom.TextureManager;
import at.jumpandjan.level.Level;


/**
 * A vertical unit providing collision.
 * @author Michael P.
 *
 */
public class Wall extends Object
{
	public Wall(double x, double y, double width, double height, Level level)
	{
		super(x, y, width, height, level);
	}

	public void render()
	{
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Wall_M.png"));
		glBegin(GL_QUADS);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y + 32);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + this.height - 32);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + this.height - 32);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y + 32);
		glEnd();
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Wall_e.png"));
		glBegin(GL_QUADS);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y + this.height);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + this.height - 32);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + this.height - 32);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y + this.height);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + 32);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + 32);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y);
		glEnd();
		glDisable(GL_TEXTURE_2D);
	}
	
	public void renderIcon() {
		glTranslated(width / 2, height / 2, 0);
		glRotatef(90, 0, 0, 1);
		glTranslated(-width / 2, -height / 2, 0);
		render("/Wall_M.png", width, 10, 0, height / 2 - 5, 32, 32, 32, 32, false);
	}
	
	static {
		Out.inf(Wall.class, "23.10.12", "Michi", null);
	}
	
	public double getDefaultWidth() {
		return 10;
	}
	
	public boolean hasDefaultWidth() {
		return true;
	}
	
	public boolean hasDefaultHeight() {
		return false;
	}
}

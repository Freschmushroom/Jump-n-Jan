package at.jumpandjan;

import at.jumpandjan.level.Level;

public class EntityHildegard extends Entity {

	private int state = 0;

	private boolean turned;

	private int cdJump;
	private int attackct;

	public EntityHildegard(double x, double y, Level level) {
		super(x, y, 32, 64, level);
	}

	public EntityHildegard(double x, double y, double width, double height,
			Level level) {
		super(x, y, width, height, level);
	}

	@Override
	public void update() {
		super.update();
		motionX = 0;
		if (collisions.contains(JumpAndJan.getPlayer())) {
			attackct++;
			state = 2;
			if (attackct > 25) {
				JumpAndJan.getPlayer().hurt(25);
				level.addSpawnable(new EntityGhost(x, y, level));
				this.kill(this);
			}
			return;
		}
		turned = !(x > Constants.getActualLevel().getPlayer().x);
		if (Math.abs(level.getPlayer().getPivotX() - this.getPivotX()) < 320
				&& Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) > 1) {
			motionX = (JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
					/ Math.abs(JumpAndJan.getPlayer().getPivotX()
							- this.getPivotX()) * 1.5f;
			state = 1;
		} else {
			state = 0;
		}

		if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
				&& onGround && JumpAndJan.getPlayer().onGround) {
			if (cdJump <= 0) {
				motionY = -10;
				cdJump = 10;
			} else
				cdJump--;
		}
	}

	@Override
	public void render() {
		// super.renderHealthbar();
		switch (state) {
		case 1: {
			super.render("/opp_hildegard_attack.png", width, height, x, y, 32,
					64, turned);
			break;
		}
		case 2: {
			super.render("/opp_hildegard_after.png", width, height, x, y, 32,
					64, turned);
			break;
		}
		default: {
			super.render("/opp_hildegard_passive.png", width, height, x, y, 32,
					64, turned);
		}
		}
	}

	public void renderIcon() {
		double h = height * 0.97;
		double w = h / 2;
		render("/Opp_hildegard_passive.png", w, h, x + (width - w) / 2, y
				+ (height - h) / 2, 32, 64, 32, 64, false);
	}
}

package at.jumpandjan;

import at.freschmushroom.Out;
import at.jumpandjan.level.Level;

public class EntityPreym extends Entity {

	private boolean turned = true;
	private int cdJump;
	private int cdAttack = 300;

	public EntityPreym(double x, double y, Level level) {
		super(x, y, 64, 128, level);
	}

	@Override
	public void update() {
		super.update();
		motionX = 0;
		if (collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.getPlayer().hurt(2);
		}
		turned = x > Constants.getActualLevel().getPlayer().x;
		motionX = (JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
				/ Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) * 1.8f;

		if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
				&& onGround && JumpAndJan.getPlayer().onGround) {
			if (cdJump <= 0) {
				motionY = -20;
				cdJump = 10;
			} else
				cdJump--;
		}
		if (cdAttack == 0 && Math.abs(x - level.getPlayer().x) <= 600) {
			Constants.getActualLevel().addSpawnable(
					new EntityQuestion(x, y, level));
			cdAttack = 120;
		} else if (cdAttack > 0) {
			cdAttack--;
		}
	}

	@Override
	public void render() {
		super.renderHealthbar();
		super.render("/opp_preym.png", width, height, x, y, 64, 128, 64, 128,
				turned);
	}

	static {
		Out.inf(EntityPreym.class, "08.12.12", "Felix", null);
	}
}

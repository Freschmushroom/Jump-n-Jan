package at.jumpandjan;

import at.jumpandjan.level.Level;

public class EntityGhost extends Entity {

	public EntityGhost(double x, double y,
			Level level) {
		super(x, y, 32, 64, level);
		isGravityApplied = false;
		isInfluencedByCollision = false;
	}

	@Override
	public void update() {
		super.update();
		motionY = - 5;
		if(y < -32) {
			this.kill(this);
		}
	}

	@Override
	public void render() {
		super.render("/opp_hildegard_ghost.png", width, height, x, y, 32, 64, true);
	}

}

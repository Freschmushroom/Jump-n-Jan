package at.jumpandjan;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.opengl.Display;

import at.freschmushroom.Errorhandling;
import at.freschmushroom.Out;
import at.freschmushroom.xml.XMLDeclaration;
import at.freschmushroom.xml.XMLFile;
import at.freschmushroom.xml.XMLNode;
import at.freschmushroom.xml.XMLTag;
import at.freschmushroom.xml.XMLWriter;
import at.jumpandjan.level.Level;

public class Constants {
	private static int DISPLAY_WIDTH;
	private static int DISPLAY_HEIGHT;
	private static int CAMERA_POSITION_X;
	private static int CAMERA_POSITION_Y;
	private static boolean paused;
	private static boolean running;
	private static boolean music;
	private static boolean seq1;
	private static Level actualLevel;
	private static String levelName;
	private static double ramPercentage;
	private static int cores;
	private static List<RAMListener> listeners;
	private static long start = 0;
	private static long end = 0;
	private static boolean counting = false;
	private static long rendering;
	private static int render;
	private static long updating;
	private static int update;
	private static boolean inUse;
	private static ArrayList<Long> updates = new ArrayList<Long>();
	private static ArrayList<Long> renders = new ArrayList<Long>();
	private static String DEFAULT_LVL_NAME;
	private static User CURRENT_USER;
	public static void load() {
		if (Display.isCreated()) {
			DISPLAY_HEIGHT = Display.getHeight();
			DISPLAY_WIDTH = Display.getWidth();
		}
		paused = false;
		running = true;
		XMLFile f = new XMLFile(new File("settings.xml"));
		XMLNode r = (XMLNode) f.getRoot();
		XMLTag music = (XMLTag) r.getChild("music", false);
		XMLTag levelName = (XMLTag) r.getChild("level", false);
		DEFAULT_LVL_NAME = levelName.getValue();
		XMLTag seq1 = (XMLTag) r.getChild("seq1", false);
		Constants.music = music.getValue().equals("true");
//		actualLevel = new Level(
//				LevelBuilder.load(Constants.levelName = levelName.getValue()));
		Constants.seq1 = seq1.getValue().equals("true");
		Runtime rt = Runtime.getRuntime();
		rt.runFinalization();
		rt.gc();
		long total = rt.totalMemory();
		long free = rt.freeMemory();
		setRamPercentage((total - free) / total);
		if (getRamPercentage() >= 0.9) {
			if (listeners != null) {
				for (RAMListener r1 : listeners) {
					r1.tooFewRAM(1.0 - getRamPercentage());
				}
			}
			if (getRamPercentage() < 0.95) {
				if (listeners != null) {
					for (RAMListener r1 : listeners) {
						r1.noFreeRAM(1.0 - getRamPercentage(),
								getRamPercentage() < 0.01);
					}
				}
			}
		}
		setCores(rt.availableProcessors());
	}

	public static String getDEFAULT_LVL_NAME() {
		return DEFAULT_LVL_NAME;
	}

	public static void setDEFAULT_LVL_NAME(String dEFAULT_LVL_NAME) {
		DEFAULT_LVL_NAME = dEFAULT_LVL_NAME;
	}

	public static void update() {
		if (Display.isCreated()) {
			DISPLAY_HEIGHT = Display.getHeight();
			DISPLAY_WIDTH = Display.getWidth();
		}
		Runtime rt = Runtime.getRuntime();
		long total = rt.totalMemory();
		long free = rt.freeMemory();
		setRamPercentage((total - free) / total);
		if (getRamPercentage() >= 0.9) {
			rt.runFinalization();
			rt.gc();
			if (listeners != null) {
				for (RAMListener r1 : listeners) {
					r1.tooFewRAM(1.0 - getRamPercentage());
				}
			}
			if (getRamPercentage() < 0.95) {
				if (listeners != null) {
					for (RAMListener r1 : listeners) {
						r1.noFreeRAM(1.0 - getRamPercentage(),
								getRamPercentage() < 0.01);
					}
				}
			}
		}
		setCores(rt.availableProcessors());
	}

	public static void writeToFile() {
		paused = true;
		XMLFile f = new XMLFile(new File("settings.xml"));
		f.clearFile();
		XMLDeclaration dec = new XMLDeclaration();
		f.setDeclaration(dec);
		XMLNode root = new XMLNode(null, "Settings");
		new XMLTag(root, "music", music ? "true" : "false");
		new XMLTag(root, "level", levelName);
		new XMLTag(root, "seq1", seq1 + "");
		XMLWriter w = new XMLWriter(f);
		w.writeToFile();
		w.writeToTerminal();
	}

	public interface RAMListener {
		public abstract void tooFewRAM(double used);

		public abstract void noFreeRAM(double used, boolean critical);
	}

	public static boolean isPaused() {
		return paused;
	}

	public static void setPaused(boolean paused) {
		Constants.paused = paused;
	}

	public static boolean isRunning() {
		return running;
	}

	public static void setRunning(boolean running) {
		Constants.running = running;
	}

	public static boolean isMusic() {
		return music;
	}

	public static void setMusic(boolean music) {
		Constants.music = music;
	}

	public static Level getActualLevel() {
		return actualLevel;
	}

	public static void setActualLevel(Level actualLevel) {
		Constants.actualLevel = actualLevel;
	}

	public static int getDISPLAY_WIDTH() {
		return DISPLAY_WIDTH;
	}

	public static int getDISPLAY_HEIGHT() {
		return DISPLAY_HEIGHT;
	}

	public static boolean isSeq1() {
		return seq1;
	}

	public static void setSeq1(boolean seq1) {
		Constants.seq1 = seq1;
	}

	public static double getRamPercentage() {
		return ramPercentage;
	}

	public static void setRamPercentage(double ramPercentage) {
		Constants.ramPercentage = ramPercentage;
	}

	public static int getCores() {
		return cores;
	}

	public static void setCores(int cores) {
		Constants.cores = cores;
	}

	public static void addRAMListener(RAMListener r) {
		if (listeners == null)
			listeners = new ArrayList<RAMListener>();
		listeners.add(r);
	}

	public static void removeRAMListener(RAMListener r) {
		if (listeners == null)
			return;
		listeners.remove(r);
	}

	public static void start() {
		start = System.nanoTime();
		end = 0;
		counting = true;
	}

	public static void stop() {
		end = System.nanoTime();
		counting = false;
	}

	public static long count() {
		if (counting) {
			return 0;
		} else {
			return end - start;
		}
	}

	public static void startRender() {
		if (!inUse) {
			start();
			inUse = true;
		} else {
			Out.err("Timing funtion already in use please quit first");
		}
	}

	public static void stopRender() {
		if (inUse) {
			stop();
			render++;
			rendering += count();
			inUse = false;
			renders.add(count());
		}
	}

	public static double totalRender() {
		return rendering;
	}

	public static double avgRender() {
		if (render != 0)
			return rendering / render;
		return 0;
	}

	public static void startUpdate() {
		if (!inUse) {
			start();
			inUse = true;

		} else {
			Out.err("Timing funtion already in use please quit first");
		}
	}

	public static void stopUpdate() {
		if (inUse) {
			stop();
			update++;
			updating += count();
			inUse = false;
			updates.add(count());
		}
	}

	public static double totalUpdate() {
		return updating;
	}

	public static double avgUpdate() {
		if (update != 0)
			return updating / update;
		return 0;
	}

	public static void showRenderUpdateTimes() {
		try {
			Out.line("Saving stats.txt");
			PrintStream f_out = new PrintStream(new FileOutputStream(
					"stats.txt"));
			f_out.println("Update Times in ms");
			for (Long s : updates) {
				f_out.println(s);
			}
			f_out.println("Render Times in nanosecond");
			for (Long s : renders) {
				f_out.println(s);
			}
			f_out.close();
			Out.line("Saved stats.txt");
			f_out.close();
		} catch (IOException e) {
			Errorhandling.handle(e);
			Out.err("Failed to save stats.png");
		}
	}

	public static int getCAMERA_POSITION_Y() {
		return CAMERA_POSITION_Y;
	}

	public static void setCAMERA_POSITION_Y(int cAMERA_POSITION_Y) {
		CAMERA_POSITION_Y = cAMERA_POSITION_Y;
	}

	public static int getCAMERA_POSITION_X() {
		return CAMERA_POSITION_X;
	}

	public static void setCAMERA_POSITION_X(int cAMERA_POSITION_X) {
		CAMERA_POSITION_X = cAMERA_POSITION_X;
	}

	public static User getCURRENT_USER() {
		return CURRENT_USER;
	}

	public static void setCURRENT_USER(User cURRENT_USER) {
		CURRENT_USER = cURRENT_USER;
	}

	static {
		Out.inf(Constants.class, "22.10.12", "Felix", null);
	}
}

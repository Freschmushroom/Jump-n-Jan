package at.jumpandjan;

import at.freschmushroom.Out;
import at.jumpandjan.level.Level;

public class EntityWaitrose extends Entity {

	private int cdJump;

	public EntityWaitrose(double x, double y, Level level) {
		super(x, y, 32, 64, level);
	}
	
	public EntityWaitrose(double x, double y, double width, double height, Level level) {
		super(x, y, width, height, level);
	}

	@Override
	public void update() {
		super.update();
		this.motionX = 0;
		if (Math.abs(JumpAndJan.getPlayer().getPivotX() - this.getPivotX()) < 100
				&& Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) > 1) {
			motionX = (JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
					/ Math.abs(JumpAndJan.getPlayer().getPivotX()
							- this.getPivotX()) * 2.9f;
		}
		if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
				&& onGround && JumpAndJan.getPlayer().onGround) {
			if (cdJump <= 0) {
				motionY = -40;
				cdJump = 10;
			} else
				cdJump--;
		}
		if (collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.getPlayer().hurt(2);
		}
	}

	@Override
	public void render() {
		super.renderHealthbar();
		super.render("/Opp_Cactus.png", width, height, x, y, 128, 256, 128, 256, state);
	}
	
	public void renderIcon() {
		super.render("/Opp_Cactus.png", 2 * width / 3, height, x + width / 6, y, 128, 256, 128, 256, false);
	}

	static {
		Out.inf(EntityWaitrose.class, "23.10.12", "Felix", null);
	}
}

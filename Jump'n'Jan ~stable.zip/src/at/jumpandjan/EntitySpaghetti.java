package at.jumpandjan;

import at.freschmushroom.Out;
import at.jumpandjan.level.Level;

public class EntitySpaghetti extends Entity {

	private int cdJump;
	private int cdSpawn;

	public EntitySpaghetti(double x, double y, Level level) {
		super(x, y, 128, 64, level);
	}

	@Override
	public void update() {
		super.update();
		if (Math.abs(JumpAndJan.getPlayer().getPivotX() - this.getPivotX()) < 200
				&& Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) > 1) {
			motionX = -(JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
					/ Math.abs(JumpAndJan.getPlayer().getPivotX()
							- this.getPivotX()) * 2.75f;
			if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
					&& onGround && JumpAndJan.getPlayer().onGround) {
				if (cdJump <= 0) {
					motionY = -25;
					cdJump = 10;
				} else
					cdJump--;
				
				
			}
			if (collisions.contains(JumpAndJan.getPlayer())) {
				this.hurt(2);
			}
			if(cdSpawn <= 0) {
				level.addSpawnable(new EntityMeatball(x, y - 32, level));
				cdSpawn = 60 * 3;
			} else
				cdSpawn--;
		}
	}

	@Override
	public void render() {
		super.renderHealthbar();
		super.render("/Opp_Spaghetti.png", width, height, x, y, 128, 64, state);
	}

	static {
		Out.inf(EntitySpaghetti.class, "06.11.12", "Felix", null);
	}
}

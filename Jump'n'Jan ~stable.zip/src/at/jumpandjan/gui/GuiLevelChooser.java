package at.jumpandjan.gui;

import java.io.File;

import at.jumpandjan.Constants;
import at.jumpandjan.level.Level;
import at.jumpandjan.level.LevelBuilder;

public class GuiLevelChooser extends Gui {
	public GuiLevelChooser() {
		initLevels();
	}
	
	private void initLevels() {
		File[] levels = new File("level/").listFiles();
		if (levels == null || levels.length == 0)
			return;
		int y = 50;
		for (File f : levels) {
			if (f.isDirectory() || !f.getName().endsWith(".xml")) {
				continue;
			}
			try {
				Level level = new Level(LevelBuilder.load(f.getAbsolutePath()));
				if (Constants.getCURRENT_USER().isUnlocked(level.getName())) {
					CompLevelButton button = new CompLevelButton(100, y, 200, 40, level);
					components.add(button);
					y += button.getHeight() + 10;
				} else {
					System.out.println(Constants.getCURRENT_USER().toString());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	class CompLevelButton extends CompButton {
		private Level level;
		public CompLevelButton(int x, int y, int width, int height, Level level) {
			super(x, y, width, height, level.getName());
			this.level = level;
			setText(level.getName());
		}

		public CompLevelButton(int x, int y, int width, Level level) {
			this(x, y, width, 32, level);
		}

		public CompLevelButton(int x, int y, Level level) {
			this(x, y, 0, level);
		}
		
	}
}

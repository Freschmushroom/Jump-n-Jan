package at.jumpandjan.level;

public class Level {

}

package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_BLEND;
import static org.lwjgl.opengl.GL11.GL_COLOR_BUFFER_BIT;
import static org.lwjgl.opengl.GL11.GL_MODELVIEW;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_PROJECTION;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBlendFunc;
import static org.lwjgl.opengl.GL11.glClear;
import static org.lwjgl.opengl.GL11.glClearColor;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glLoadIdentity;
import static org.lwjgl.opengl.GL11.glMatrixMode;
import static org.lwjgl.opengl.GL11.glOrtho;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glViewport;

import java.awt.Canvas;
import java.awt.Frame;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JOptionPane;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.openal.AL;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import at.jumpandjan.audio.SoundContainer;

public class JumpAndJan implements Constants.RAMListener{
	public static Frame parent;
	public static Canvas canvas;

	public static void main(String[] args) {
		Constants.load();
		Constants.addRAMListener(new JumpAndJan());
		parent = initFrame();
		SoundContainer.init();
		if (Constants.isSeq1()) {
			SequenceParty sp = new SequenceParty();
			sp.start();
			try {
				sp.join();
			} catch (InterruptedException e) {
			}
		}
		try {
			Display.setTitle("Jump\'n\'Jan");
			Display.setDisplayMode(new DisplayMode(640, 480));
			Display.create();
			Display.setParent((Canvas) JumpAndJan.canvas);
			Display.setVSyncEnabled(true);
			JumpAndJan.parent.requestFocus();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, 640, 480, 0, 1, -1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glViewport(0, 0, 640, 480);

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		Display.setTitle("Jump'n'Jan");
		SoundContainer.startGameMusic();
		while (!Display.isCloseRequested() && Constants.isRunning()) {
			Constants.update();
			System.out.println(Constants.getRamPercentage() + "");
			glClearColor(0, 0, 1, 0);
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			glTranslated(-getPlayer().x + 304, 0, 0);
			Constants.startRender();
			Constants.getActualLevel().render();
			Constants.stopRender();
			if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
				getPlayer().motionX = -3;
			} else if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
				getPlayer().motionX = 3;
			} else
				getPlayer().motionX = 0;
			while (Keyboard.next()) {
				if (Keyboard.getEventKeyState()
						&& Keyboard.getEventKey() == Keyboard.KEY_SPACE
						&& getPlayer().onGround) {
					getPlayer().motionY -= 20;
				}
			}
			if (!Constants.isPaused()) {
				Constants.startUpdate();
				Constants.getActualLevel().update();
				Constants.stopUpdate();
			}
			Display.update();
			Display.sync(60);
			//System.out.println("AVG render in ms: " + Constants.avgRender());
			//System.out.println("AVG update in ms: " + Constants.avgUpdate());
		}
		AL.destroy();
		Display.destroy();
		Constants.showRenderUpdateTimes();
	}

	private JumpAndJan() {
		Out.line("Listeners started");
	}
	
	public static EntityPlayer getPlayer() {
		return Constants.getActualLevel().getPlayer();
	}

	public static void tooot() {
		Constants.setRunning(false);
		SoundContainer.stopGameMusic();
		SoundContainer.gameOver.playAsSoundEffect(1, 1, true);
		while (true) {
			Constants.update();
			glClearColor(1, 0, 0, 0);
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			glEnable(GL_TEXTURE_2D);
			FontRenderer.instance.drawStringAt("TOT", 10, 10, 640, 450,
					new float[] { 0, 1, 0 });
			glDisable(GL_TEXTURE_2D);
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
				break;
			}
			Display.update();
			Display.sync(60);
		}
		try {
			AL.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Display.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	public static void wooon() {
		Constants.setRunning(false);
		SoundContainer.stopGameMusic();
		while (true) {
			Constants.update();
			glClearColor(0, 0, 1, 1);
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			glEnable(GL_TEXTURE_2D);
			FontRenderer.instance.drawStringAt("WON", 10, 10, 620, 430,
					new float[] { 0, 1, 0 });
			glDisable(GL_TEXTURE_2D);
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
				break;
			}
			Display.update();
			Display.sync(60);
		}
		try {
			AL.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Display.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	private static Frame initFrame() {
		try {
			Constants.load();
			Frame f = new Frame("Jump\'n\'Jan");
			canvas = new Canvas();
			f.add(canvas);
			f.addFocusListener(new FocusListener() {
				@Override
				public void focusLost(FocusEvent e) {
					Constants.setPaused(true);
				}

				@Override
				public void focusGained(FocusEvent e) {
					Constants.setPaused(false);
				}
			});
			f.addWindowListener(new WindowListener() {
				@Override
				public void windowOpened(WindowEvent e) {
				}

				@Override
				public void windowClosing(WindowEvent e) {
					((Frame) e.getSource()).dispose();
					Constants.setRunning(false);
					Constants.writeToFile();
					Constants.showRenderUpdateTimes();
					System.exit(0);
				}

				@Override
				public void windowClosed(WindowEvent e) {
				}

				@Override
				public void windowIconified(WindowEvent e) {
				}

				@Override
				public void windowDeiconified(WindowEvent e) {
				}

				@Override
				public void windowActivated(WindowEvent e) {
				}

				@Override
				public void windowDeactivated(WindowEvent e) {
				}
			});
			f.setVisible(true);
			f.setSize(640 + f.getInsets().left + f.getInsets().right,
					480 + f.getInsets().top + f.getInsets().bottom);
			f.setLocationRelativeTo(null);
			return f;
		} catch (Exception ex) {
			return null;
		}
	}

	@Override
	public void tooFewRAM(double used) {
		Out.err("Not enough RAM already " + used + " used.");
	}

	@Override
	public void noFreeRAM(double used, boolean critical) {
		if(critical) {
			Out.err("Not enough RAM. Shutting down virtual machine");
		} else {
			tooFewRAM(used);
		}
	}
}

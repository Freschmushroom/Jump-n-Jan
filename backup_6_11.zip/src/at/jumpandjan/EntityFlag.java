package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;
import at.jumpandjan.level.Level;

public class EntityFlag extends Entity {
	private String imgName = "";

	public EntityFlag(double x, String imgName, Level level) {
		super(x, 396, 32, 64, level);
		this.imgName=imgName;
	}

	public void render() {
		glPushMatrix();
		glTranslated(x, y, 0);
		if (state) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture(imgName));
		float f = 1 / 32f;
		glColor3f(1, 1, 1);
		float f1 = 1 / 64f;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, 64 * f1);
		glVertex2d(0, height);
		glTexCoord2f(32 * f, 64 * f1);
		glVertex2d(width, height);
		glTexCoord2f(32 * f, 0);
		glVertex2d(width, 0);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}

	public void spawn() {
		JumpAndJan.getPlayer().x = this.x;
		JumpAndJan.getPlayer().y = this.y;
	}
	
	@Override
	public void update() {
		for (Object o : collision) {
			if (x >= o.x && x <= o.x + o.width && y >= o.y
					&& y <= o.y + o.height || x + width >= o.x
					&& x + width <= o.x + o.width && y >= o.y
					&& y <= o.y + o.height || x + width >= o.x
					&& x + width <= o.x + o.width && y + height >= o.y
					&& y + height <= o.y + o.height || x >= o.x
					&& x <= o.x + o.width && y + height >= o.y
					&& y + height <= o.y + o.height) {
				motionX = 0;
				if (o instanceof Entity)
					collisions.add((Entity) o);
				break;
			}
		}
	}
}

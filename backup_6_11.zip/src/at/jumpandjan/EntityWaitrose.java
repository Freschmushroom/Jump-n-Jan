package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;
import at.jumpandjan.level.Level;

public class EntityWaitrose extends Entity {

	private int cdJump;

	public EntityWaitrose(double x, double y, Level level) {
		super(x, y, 32, 64, level);
	}

	@Override
	public void update() {
		super.update();
		this.motionX = 0;
		if (Math.abs(JumpAndJan.getPlayer().getPivotX() - this.getPivotX()) < 320
				&& Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) > 1) {
			motionX = (JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
					/ Math.abs(JumpAndJan.getPlayer().getPivotX()
							- this.getPivotX()) * 1.5f;
		}
		if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
				&& onGround && JumpAndJan.getPlayer().onGround) {
			if (cdJump <= 0) {
				motionY = -20;
				cdJump = 10;
			} else
				cdJump--;
		}
		if (collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.getPlayer().hurt(2);
		}
	}

	@Override
	public void render() {
		super.renderHealthbar();
		glPushMatrix();
		glTranslated(x, y, 0);
		if (state) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture("/Opp_Cactus.png"));
		float f = 1 / 128f;
		float f1 = 1 / 256f;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, 256 * f1);
		glVertex2d(0, height);
		glTexCoord2f(128 * f, 256 * f1);
		glVertex2d(width, height);
		glTexCoord2f(128 * f, 0);
		glVertex2d(width, 0);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}

}

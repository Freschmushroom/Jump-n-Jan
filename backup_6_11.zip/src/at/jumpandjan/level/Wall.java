package at.jumpandjan.level;

import java.io.Serializable;

import at.jumpandjan.JumpAndJan;

public class Wall implements Serializable, LevelElement {
	private int pos;
	private int length;
	private int height;

	public Wall(int pos, int length, int height) {
		this.pos = pos;
		this.length = length;
		this.height = height;
	}

	public int getPos() {
		return pos;
	}

	public int getLength() {
		return length;
	}

	@Override
	public at.jumpandjan.Object getElement(Level level) {
		return new at.jumpandjan.Wall(pos, height,
				10, length, level);
	}

}

package at.jumpandjan.level;

public interface LevelElement {
	public abstract at.jumpandjan.Object getElement(Level level);
}

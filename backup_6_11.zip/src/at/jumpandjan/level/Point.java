package at.jumpandjan.level;

import at.jumpandjan.EntityHaarfarbe;
import at.jumpandjan.Object;

public class Point implements LevelElement {
	private int x;
	private int y;
	
	public Point(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}

	@Override
	public Object getElement(Level level) {
		return new EntityHaarfarbe(x, y, level);
	}

}

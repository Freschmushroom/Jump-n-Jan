package at.jumpandjan.level;

import java.util.ArrayList;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import static org.lwjgl.opengl.GL11.*;

public class LevelMaker {
	public static ArrayList<at.jumpandjan.Object> firstLayer = new ArrayList<at.jumpandjan.Object>();
	public static ArrayList<at.jumpandjan.Object> secondLayer = new ArrayList<at.jumpandjan.Object>();
	public static ArrayList<at.jumpandjan.Object> thirdLayer = new ArrayList<at.jumpandjan.Object>();
	
	public static void main(String[] args) {
		try {
			Display.setDisplayMode(new DisplayMode(1920, 1080));
			Display.create();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, 640, 480, 0, 1, -1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		
		while (!Display.isCloseRequested()) {
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			
			
			
			Display.update();
			Display.sync(60);
		}
	}
}

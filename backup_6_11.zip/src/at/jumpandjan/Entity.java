package at.jumpandjan;

import static org.lwjgl.opengl.GL11.*;

import java.util.ArrayList;

import at.jumpandjan.level.Level;

public class Entity extends Object {
	protected boolean state;
	protected ArrayList<Entity> collisions;
	protected boolean alive = true;
	protected boolean isGravityApplied = true;
	protected Entity killer;
	
	protected int hp = 200;
	private int maxHP;

	public Entity(double x, double y, double width, double height, Level level) {
		super(x, y, width, height, level);
		collisions = new ArrayList<Entity>();
	}

	public void update() {
		if (motionX < 0)
			state = true;
		else if (motionX > 0)
			state = false;
		motionY += 1.4;
		collisions.clear();
		label1: for (int i = 0; i < 20000; i++) {
			double x = this.x + motionX * 0.00005;
			for (Object o : collision) {
				if (x >= o.x && x <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height || x >= o.x
						&& x <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height) {
					motionX = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label1;
				}
				if (o.x >= x && o.x <= x + width && o.y >= y
						&& o.y <= y + height || o.x + o.width >= x
						&& o.x + o.width <= x + width && o.y >= y
						&& o.y <= y + height || o.x + o.width >= x
						&& o.x + o.width <= x + width && o.y + o.height >= y
						&& o.y + o.height <= y + height || o.x >= x
						&& o.x <= x + width && o.y + o.height >= y
						&& o.y + o.height <= y + height) {
					motionX = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label1;
				}
			}
			this.x = x;
		}
		onGround = false;
		label2: for (int i = 0; i < 20000; i++) {
			double y = this.y + motionY * 0.00005;
			for (Object o : collision) {
				if (x >= o.x && x <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height || x >= o.x
						&& x <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height) {
					if(motionY > 0)
						onGround = true;
					motionY = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label2;
				}
			}
			this.y = y;
		}
		if(this.y > 480) {
			level.getDeadObjects().add(this);
		}
	}

	public double getPivotX() {
		return x + width / 2D;
	}

	public double getPivotY() {
		return y + height / 2D;
	}

	public void setHp(int hp) {
		this.hp = hp;
	}

	public int getHp() {
		return hp;
	}
	
	protected void renderHealthbar() {
		glPushMatrix();
		glTranslated(x, y - 10, 0);
		
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/ProgressBar.png"));
		
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(1, 0);
		glVertex2d(width, 0);
		glTexCoord2f(1, 1);
		glVertex2d(width, 4);
		glTexCoord2f(0, 1);
		glVertex2d(0, 4);
		glEnd();
		
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Progress.png"));
		float health = this.getHp() / 200F;
		double x2 = 1 / 128D * width;
		double x3 = health * width - 1 / 128D * width;
		
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(x2, 1);
		glTexCoord2f(1, 0);
		glVertex2d(x3, 1);
		glTexCoord2f(1, 1);
		glVertex2d(x3, 3);
		glTexCoord2f(0, 1);
		glVertex2d(x2, 3);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}

	public void kill(Entity e) {
		this.alive = false;
		killer = e;
	}

	public boolean isAlive() {
		return alive;
	}
	
	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}
}

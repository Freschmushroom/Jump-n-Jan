package at.jumpandjan;

import at.jumpandjan.level.Level;

public class EntityFinishFlag extends EntityFlag {
	public EntityFinishFlag(double x, Level level) {
		super(x, "/Finish_Flag.png", level);
	}

	@Override
	public void update() {
		super.update();
		if(collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.tooot();
		}
	}
}

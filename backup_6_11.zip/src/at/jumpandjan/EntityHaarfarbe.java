package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glColor3f;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;
import at.jumpandjan.level.Level;

public class EntityHaarfarbe extends Entity {

	public EntityHaarfarbe(double x, double y, Level level) {
		super(x, y, 16, 16, level);
		isGravityApplied = false;
	}

	@Override
	public void update() {
		super.update();
		if(collisions.contains(level.getPlayer())) {
			level.getPlayer().addPoint();
			this.kill(level.getPlayer());
		}
	}

	@Override
	public void render() {
		glPushMatrix();
		glTranslated(x, y, 0);
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture("/Janny_Farbe.png"));
		float f = 1 / 32f;
		glColor3f(1, 1, 1);
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, 28 * f);
		glVertex2d(0, height);
		glTexCoord2f(26 * f, 28 * f);
		glVertex2d(width, height);
		glTexCoord2f(26 * f, 0);
		glVertex2d(width, 0);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}

}

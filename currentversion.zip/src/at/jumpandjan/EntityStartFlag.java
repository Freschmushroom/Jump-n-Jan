package at.jumpandjan;

import at.jumpandjan.level.Level;

public class EntityStartFlag extends EntityFlag {

	public EntityStartFlag(double x, Level level) {
		super(x, "/Start_Flag.png", level);
	}

	@Override
	public void update() {
		super.update();
	}

}

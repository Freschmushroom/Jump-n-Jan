package at.jumpandjan;

import java.awt.Dimension;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.ApplicationFrame;
import org.lwjgl.opengl.Display;

import at.jumpandjan.level.Level;
import at.jumpandjan.level.LevelBuilder;
import at.xml.XMLDeclaration;
import at.xml.XMLFile;
import at.xml.XMLNode;
import at.xml.XMLTag;
import at.xml.XMLWriter;

public class Constants {
	private static int DISPLAY_WIDTH;
	private static int DISPLAY_HEIGHT;
	private static boolean paused;
	private static boolean running;
	private static boolean music;
	private static boolean seq1;
	private static Level actualLevel;
	private static String levelName;
	private static double ramPercentage;
	private static int cores;
	private static List<RAMListener> listeners;
	private static long start = 0;
	private static long end = 0;
	private static boolean counting = false;
	private static long rendering;
	private static int render;
	private static long updating;
	private static int update;
	private static boolean inUse;
	private static ArrayList<Long> updates = new ArrayList<Long>();
	private static ArrayList<Long> renders = new ArrayList<Long>();

	public static void load() {
		if (Display.isCreated()) {
			DISPLAY_HEIGHT = Display.getHeight();
			DISPLAY_WIDTH = Display.getWidth();
		}
		paused = false;
		running = true;
		XMLFile f = new XMLFile(new File("settings.xml"));
		XMLNode r = (XMLNode) f.getRoot();
		XMLTag music = (XMLTag) r.getChild("music", false);
		XMLTag levelName = (XMLTag) r.getChild("level", false);
		XMLTag seq1 = (XMLTag) r.getChild("seq1", false);
		Constants.music = music.getValue().equals("true");
		actualLevel = new Level(
				LevelBuilder.load(Constants.levelName = levelName.getValue()));
		Constants.seq1 = seq1.getValue().equals("true");
		Runtime rt = Runtime.getRuntime();
		rt.runFinalization();
		rt.gc();
		long total = rt.totalMemory();
		long free = rt.freeMemory();
		setRamPercentage((total - free) / total);
		if (getRamPercentage() >= 0.9) {
			if (listeners != null) {
				for (RAMListener r1 : listeners) {
					r1.tooFewRAM(1.0 - getRamPercentage());
				}
			}
			if (getRamPercentage() < 0.95) {
				if (listeners != null) {
					for (RAMListener r1 : listeners) {
						r1.noFreeRAM(1.0 - getRamPercentage(),
								getRamPercentage() < 0.01);
					}
				}
			}
		}
		setCores(rt.availableProcessors());
	}

	public static void update() {
		if (Display.isCreated()) {
			DISPLAY_HEIGHT = Display.getHeight();
			DISPLAY_WIDTH = Display.getWidth();
		}
	}

	public static void writeToFile() {
		paused = true;
		XMLFile f = new XMLFile(new File("settings.xml"));
		f.clearFile();
		XMLDeclaration dec = new XMLDeclaration();
		f.setDeclaration(dec);
		XMLNode root = new XMLNode(null, "Settings");
		new XMLTag(root, "music", music ? "true" : "false");
		new XMLTag(root, "level", levelName);
		new XMLTag(root, "seq1", seq1 + "");
		XMLWriter w = new XMLWriter(f);
		w.writeToFile();
		w.writeToTerminal();
	}

	public interface RAMListener {
		public abstract void tooFewRAM(double used);

		public abstract void noFreeRAM(double used, boolean critical);
	}

	public static boolean isPaused() {
		return paused;
	}

	public static void setPaused(boolean paused) {
		Constants.paused = paused;
	}

	public static boolean isRunning() {
		return running;
	}

	public static void setRunning(boolean running) {
		Constants.running = running;
	}

	public static boolean isMusic() {
		return music;
	}

	public static void setMusic(boolean music) {
		Constants.music = music;
	}

	public static Level getActualLevel() {
		return actualLevel;
	}

	public static void setActualLevel(Level actualLevel) {
		Constants.actualLevel = actualLevel;
	}

	public static int getDISPLAY_WIDTH() {
		return DISPLAY_WIDTH;
	}

	public static int getDISPLAY_HEIGHT() {
		return DISPLAY_HEIGHT;
	}

	public static boolean isSeq1() {
		return seq1;
	}

	public static void setSeq1(boolean seq1) {
		Constants.seq1 = seq1;
	}

	public static double getRamPercentage() {
		return ramPercentage;
	}

	public static void setRamPercentage(double ramPercentage) {
		Constants.ramPercentage = ramPercentage;
	}

	public static int getCores() {
		return cores;
	}

	public static void setCores(int cores) {
		Constants.cores = cores;
	}

	public static void addRAMListener(RAMListener r) {
		if (listeners == null)
			listeners = new ArrayList<RAMListener>();
		listeners.add(r);
	}

	public static void removeRAMListener(RAMListener r) {
		if (listeners == null)
			return;
		listeners.remove(r);
	}

	public static void start() {
		start = System.currentTimeMillis();
		end = 0;
		counting = true;
	}

	public static void stop() {
		end = System.currentTimeMillis();
		counting = false;
	}

	public static long count() {
		if (counting) {
			return 0;
		} else {
			return end - start;
		}
	}

	public static void startRender() {
		if (!inUse) {
			start();
			inUse = true;
		} else {
			Out.err("Timing funtion already in use please quit first");
		}
	}

	public static void stopRender() {
		if (inUse) {
			stop();
			render++;
			rendering += count();
			inUse = false;
			renders.add(count());
		}
	}

	public static double totalRender() {
		return rendering;
	}

	public static double avgRender() {
		if (render != 0)
			return rendering / render;
		return 0;
	}

	public static void startUpdate() {
		if (!inUse) {
			start();
			inUse = true;
		} else {
			Out.err("Timing funtion already in use please quit first");
		}
	}

	public static void stopUpdate() {
		if (inUse) {
			stop();
			update++;
			updating += count();
			inUse = false;
			updates.add(count());
		}
	}

	public static double totalUpdate() {
		return updating;
	}

	public static double avgUpdate() {
		if (update != 0)
			return updating / update;
		return 0;
	}

	public static void showRenderUpdateTimes() {
		ApplicationFrame af = new ApplicationFrame("Times");
		CategoryDataset dataset = createDataSet();
		JFreeChart chart = createChart(dataset);
		ChartPanel panel = new ChartPanel(chart);
		panel.setPreferredSize(new Dimension(640, 480));
		af.setContentPane(panel);
		af.pack();
		af.setVisible(true);
		af.setDefaultCloseOperation(ApplicationFrame.EXIT_ON_CLOSE);
		try {
			af.wait(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		af.dispose();
	}

	private static JFreeChart createChart(CategoryDataset dataset) {
		JFreeChart chart = ChartFactory.createLineChart(
				"Render and Update Times", "Ticks", "Time", dataset,
				PlotOrientation.VERTICAL, true, true, false);
		return chart;
	}

	private static CategoryDataset createDataSet() {
		DefaultCategoryDataset data = new DefaultCategoryDataset();
		Iterator<Long> i = updates.iterator();
		int cU = 0;
		int cR = 0;
		while (i.hasNext()) {
			data.addValue(i.next(), "Updates", (cU + ""));
			cU++;
		}
		i = renders.iterator();
		while (i.hasNext()) {
			data.addValue(i.next(), "Renders", (cR + ""));
		}
		return data;
	}
}

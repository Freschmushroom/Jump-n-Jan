import java.awt.Rectangle;


public class CollisionTest {
	public static void main(String[] args) {
		System.out.println("HEYHO");
	}
}

package at.jumpandjan;

public class DamageSource {
	private int damage;
	
	public DamageSource(int damage) {
		this.damage = damage;
	}
	
	public int getDamage() {
		return damage;
	}
}

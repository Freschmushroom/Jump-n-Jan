package at.jumpandjan;

public class InterruptUpdateException extends RuntimeException {

}

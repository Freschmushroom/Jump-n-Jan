package at.jumpandjan.gui;

public interface ActionListener {
	public void onClicked(CompButton source);
	public void onReleased(CompButton source);
	public void onPressed(CompButton source);
}

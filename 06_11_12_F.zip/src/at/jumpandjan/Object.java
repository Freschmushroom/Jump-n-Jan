package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;

import java.util.ArrayList;
import java.util.List;

import at.freschmushroom.TextureManager;
import at.jumpandjan.level.Level;

public class Object
{
	public List<Object> collision = new ArrayList<Object>();
	public double x;
	public double y;
	public double width;
	public double height;
	public double motionX;
	public double motionY;
	public boolean onGround;

	public Level level;
	
	public Object(double x, double y, double width, double height, Level level)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.level = level;
	}

	public void update()
	{

	}

	public void render()
	{
		render("/none", width, height, x, y, (float)width, (float)height, false);
	}
	
	public void render(String texture, double width, double height, double x, double y, float rWidth, float rHeight, boolean turned) {
		render(texture, width, height, x, y, rWidth, rHeight, (float)width, (float)height, turned);
	}
	
	public void render(String texture, double width, double height, double x, double y, float rWidth, float rHeight, float sWidth, float sHeight, boolean turned) {
		glPushMatrix();
		glTranslated(x, y, 0);
		if (turned) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture(texture));
		float f = 1 / sWidth;
		float f1 = 1 / sHeight;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, rHeight * f1);
		glVertex2d(0, height);
		glTexCoord2f(rWidth * f, rHeight * f1);
		glVertex2d(width, height);
		glTexCoord2f(rWidth * f, 0);
		glVertex2d(width, 0);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}
}

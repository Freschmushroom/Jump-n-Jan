package at.jumpandjan;

import static org.lwjgl.opengl.GL11.*;
import at.freschmushroom.TextureManager;
import at.jumpandjan.level.Level;
import at.freschmushroom.Out;

public class EntityPlayer extends Entity {
	private int attacking;

	private int points = 0;

	public EntityPlayer(double x, double y, double width, double height,
			Level level) {
		super(x, y, width, height, level);
	}

	public void update() {
		super.update();
		if (attacking > 0)
			attacking--;
	}

	public void render() {
		glPushMatrix();
		glTranslated(x, y, 0);
		if (state) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture("/Janny_Knight.png"));
		glColor3f(1, 1, 1);
		float f = 1 / 32f;
		float f1 = 1 / 256f;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, 60 * f1);
		glVertex2d(0, height);
		glTexCoord2f(28 * f, 60 * f1);
		glVertex2d(width, height);
		glTexCoord2f(28 * f, 0);
		glVertex2d(width, 0);
		if (attacking <= 0) {
			glTexCoord2f(0, 88 * f1);
			glVertex2d(9, 8);
			glTexCoord2f(0, 114 * f1);
			glVertex2d(9, 34);
			glTexCoord2f(17 * f, 114 * f1);
			glVertex2d(28, 34);
			glTexCoord2f(17 * f, 88 * f1);
			glVertex2d(28, 8);
		} else {
			glTexCoord2f(0, 61 * f1);
			glVertex2d(9, 13);
			glTexCoord2f(0, 86 * f1);
			glVertex2d(9, 39);
			glTexCoord2f(17 * f, 86 * f1);
			glVertex2d(28, 39);
			glTexCoord2f(17 * f, 61 * f1);
			glVertex2d(28, 13);
		}
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
		
		glPushMatrix();
		glLoadIdentity();
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/ProgressBar.png"));
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2f(64, 10);
		glTexCoord2f(1, 0);
		glVertex2f(576, 10);
		glTexCoord2f(1, 1);
		glVertex2f(576, 18);
		glTexCoord2f(0, 1);
		glVertex2f(64, 18);
		glEnd();
		
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Progress.png"));
		float health = this.getHp() / 200F;
		float x2 = health * 504 + 69;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2f(69, 12);
		glTexCoord2f(1, 0);
		glVertex2f(x2, 12);
		glTexCoord2f(1, 1);
		glVertex2f(x2, 16);
		glTexCoord2f(0, 1);
		glVertex2f(69, 16);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
	}

	public void hurt(int hitpoints) {
		if (hp <= hitpoints) {
			hp = 0;
			JumpAndJan.tooot();
		} else {
			hp -= hitpoints;
		}
	}

	public void attack() {
		attacking = 25;
	}
	
	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}
	
	public void addPoint() {
		points++;
	}
	
	static {
		Out.inf(EntityPlayer.class, "23.10.12", "Michi", null);
	}
}

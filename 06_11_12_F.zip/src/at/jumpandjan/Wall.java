package at.jumpandjan;

import static org.lwjgl.opengl.GL11.*;
import at.freschmushroom.TextureManager;
import at.jumpandjan.level.Level;
import at.freschmushroom.Out;

public class Wall extends Object
{
	public Wall(double x, double y, double width, double height, Level level)
	{
		super(x, y, width, height, level);
	}

	public void render()
	{
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Wall_M.png"));
		glBegin(GL_QUADS);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y + 32);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + this.height - 32);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + this.height - 32);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y + 32);
		glEnd();
		TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Wall_e.png"));
		glBegin(GL_QUADS);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y + this.height);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + this.height - 32);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + this.height - 32);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y + this.height);
		glTexCoord2f(0, 0);
		glVertex2d(this.x + this.width, this.y);
		glTexCoord2f(1, 0);
		glVertex2d(this.x + this.width, this.y + 32);
		glTexCoord2f(1, 1);
		glVertex2d(this.x, this.y + 32);
		glTexCoord2f(0, 1);
		glVertex2d(this.x, this.y);
		glEnd();
		glDisable(GL_TEXTURE_2D);
	}
	
	static {
		Out.inf(Wall.class, "23.10.12", "Michi", null);
	}
}

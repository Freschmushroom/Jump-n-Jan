package at.jumpandjan;

import at.jumpandjan.level.Level;
import at.freschmushroom.Out;

public class EntityFlag extends Entity {
	private String imgName = "";

	public EntityFlag(double x, String imgName, Level level) {
		super(x, 396, 32, 64, level);
		this.imgName = imgName;
	}

	public void render() {
		super.render(imgName, width, height, x, y, 32f, 64f, state);
	}

	public void spawn() {
		JumpAndJan.getPlayer().x = this.x;
		JumpAndJan.getPlayer().y = this.y;
	}

	@Override
	public void update() {
		for (Object o : collision) {
			if (x >= o.x && x <= o.x + o.width && y >= o.y
					&& y <= o.y + o.height || x + width >= o.x
					&& x + width <= o.x + o.width && y >= o.y
					&& y <= o.y + o.height || x + width >= o.x
					&& x + width <= o.x + o.width && y + height >= o.y
					&& y + height <= o.y + o.height || x >= o.x
					&& x <= o.x + o.width && y + height >= o.y
					&& y + height <= o.y + o.height) {
				motionX = 0;
				if (o instanceof Entity)
					collisions.add((Entity) o);
				break;
			}
		}
	}

	static {
		Out.inf(EntityFlag.class, "22.10.12", "Michael", null);
	}
}

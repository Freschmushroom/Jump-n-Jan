package at.jumpandjan.level;

import java.io.Serializable;

import at.freschmushroom.Out;
import at.jumpandjan.EntityMeatball;
import at.jumpandjan.EntityPedobaer;
import at.jumpandjan.EntityPsy;
import at.jumpandjan.EntityWaitrose;

public class Spawn implements Serializable, LevelElement {
	private int pos;
	private String type;
	private String kind;

	@Override
	public at.jumpandjan.Object getElement(Level level) {
		if (type.equals("opp") && kind.equals("meatball")) {
			return new EntityMeatball(pos, 0, level);
		} else if (type.equals("opp") && kind.equals("waitrose")) {
			return new EntityWaitrose(pos, 0, level);
		} else if (type.equals("opp") && kind.equals("psy")) {
			return new EntityPsy(pos, 0, level);
		} else if (type.equals("opp") && kind.equals("pedo")) {
			return new EntityPedobaer(pos, 0, level);
		}
		Out.err("Mob " + type + "_" + kind + " does not exist. Spawning Meatball instead.");
		return new EntityMeatball(pos, 0, level);
	}

	public int getPos() {
		return pos;
	}

	public String getType() {
		return type;
	}

	public String getKind() {
		return kind;
	}

	public Spawn(int pos, String type, String kind) {
		super();
		this.pos = pos;
		this.type = type;
		this.kind = kind;
	}

	static {
		Out.inf(Spawn.class, "23.10.12", "Felix", null);
	}
}

package at.jumpandjan.level;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;

import at.freschmushroom.Out;
import at.freschmushroom.xml.XMLAttribut;
import at.freschmushroom.xml.XMLElement;
import at.freschmushroom.xml.XMLFile;
import at.freschmushroom.xml.XMLNode;
import at.freschmushroom.xml.XMLTag;

public class LevelBuilder implements Serializable{
	private ArrayList<LevelElement> elements = new ArrayList<LevelElement>();
	private int index = 0;
	private String name = "";
	private long points = 0;
	private int start = 0;
	private int finish = 0;

	public static LevelBuilder load(String name) {
		XMLFile f = new XMLFile(new File("Level\\" + name));
		LevelBuilder b = new LevelBuilder();
		XMLNode r = (XMLNode) f.root;
		XMLNode info = (XMLNode) r.getChild("Info", false);
		b.index = Integer
				.parseInt(((XMLAttribut) info.getChild("index", false))
						.getValue());
		b.name = ((XMLAttribut) info.getChild("name", false)).getValue();
		b.points = Integer.parseInt(((XMLAttribut) info.getChild("points",
				false)).getValue());
		b.start = Integer.parseInt(((XMLTag) r.getChild("Start", false))
				.getValue());
		b.finish = Integer.parseInt(((XMLTag) r.getChild("Finish", false))
				.getValue());
		for(XMLElement e : r.getChildren()) {
			if(e instanceof XMLNode) {
				XMLNode n = (XMLNode) e;
				if(n.getName().equalsIgnoreCase("wall")) {
					int pos, length, height;
					pos = Integer.parseInt(((XMLAttribut) n.getChild("pos", false)).getValue());
					length = Integer.parseInt(((XMLAttribut) n.getChild("length", false)).getValue());
					height = Integer.parseInt(((XMLAttribut) n.getChild("height", false)).getValue());
					b.elements.add(new Wall(pos, length, height));
				} else if(n.getName().equalsIgnoreCase("spawn")) {
					int pos;
					String type, kind;
					pos = Integer.parseInt(((XMLAttribut) n.getChild("pos", false)).getValue());
					type = ((XMLAttribut) n.getChild("type", false)).getValue();
					kind = ((XMLAttribut) n.getChild("kind", false)).getValue();
					b.elements.add(new Spawn(pos, type, kind));
				} else if(n.getName().equalsIgnoreCase("floor")) {
					int pos, length, height;
					pos = Integer.parseInt(((XMLAttribut) n.getChild("pos", false)).getValue());
					length = Integer.parseInt(((XMLAttribut) n.getChild("length", false)).getValue());
					height = Integer.parseInt(((XMLAttribut) n.getChild("height", false)).getValue());
					b.elements.add(new Floor(pos, length, height));
				} else if(n.getName().equalsIgnoreCase("point")) {
					int x, y;
					x = Integer.parseInt(((XMLAttribut) n.getChild("x", false)).getValue());
					y = Integer.parseInt(((XMLAttribut) n.getChild("y", false)).getValue());
					b.elements.add(new Point(x, y));
				}
			}
		}
		return b;
	}

	public ArrayList<LevelElement> getElements() {
		return elements;
	}

	public int getIndex() {
		return index;
	}

	public String getName() {
		return name;
	}

	public long getPoints() {
		return points;
	}

	public int getStart() {
		return start;
	}

	public int getFinish() {
		return finish;
	}

	static {
		Out.inf(LevelBuilder.class, "23.10.12", "Felix", null);
	}
}

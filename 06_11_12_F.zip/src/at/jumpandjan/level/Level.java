package at.jumpandjan.level;

import java.util.ArrayList;

import static org.lwjgl.opengl.GL11.*;

import at.freschmushroom.Out;
import at.freschmushroom.TextureManager;
import at.jumpandjan.Entity;
import at.jumpandjan.EntityFinishFlag;
import at.jumpandjan.EntityPlayer;
import at.jumpandjan.EntityStartFlag;
import at.jumpandjan.Object;

public class Level {
	private int playerPos;
	private int start;
	private int finish;
	private String name;
	private int points;
	private EntityPlayer player;
	private ArrayList<at.jumpandjan.Object> first = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> second = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> third = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> second_point = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> deadObjects = new ArrayList<at.jumpandjan.Object>();

	public Level(LevelBuilder lb) {
		playerPos = (start = lb.getStart());
		finish = lb.getFinish();
		name = lb.getName();
		for (LevelElement le : lb.getElements()) {
			if (le instanceof Wall || le instanceof Floor) {
				first.add(le.getElement(this));
			} else if (le instanceof Spawn) {
				second.add(le.getElement(this));
			} else if (le instanceof Point) {
				second_point.add(le.getElement(this));
			}
		}
		first.add(new EntityStartFlag(start, this));
		first.add(new EntityFinishFlag(finish, this));
		third.add(player = new EntityPlayer(start, 100, 32, 64, this));
		for (at.jumpandjan.Object o : second) {
			for (at.jumpandjan.Object w : first) {
				o.collision.add(w);
			}
		}
		for (at.jumpandjan.Object o : first) {
			for (at.jumpandjan.Object w : third) {
				if (o instanceof EntityFinishFlag
						|| o instanceof EntityStartFlag) {
					o.collision.add(w);
				} else {
					w.collision.add(o);
				}
			}
		}
		for (at.jumpandjan.Object o : second) {
			for (at.jumpandjan.Object w : third) {
				o.collision.add(w);
			}
		}
		for (at.jumpandjan.Object o : second_point) {
			for (at.jumpandjan.Object w : third) {
				o.collision.add(w);
			}
		}
	}

	public int getPlayerPos() {
		return playerPos;
	}

	public void setPlayerPos(int playerPos) {
		this.playerPos = playerPos;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getFinish() {
		return finish;
	}

	public void setFinish(int finish) {
		this.finish = finish;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public ArrayList<at.jumpandjan.Object> getFirst() {
		return first;
	}

	public void setFirst(ArrayList<at.jumpandjan.Object> first) {
		this.first = first;
	}

	public ArrayList<at.jumpandjan.Object> getSecond() {
		return second;
	}

	public void setSecond(ArrayList<at.jumpandjan.Object> second) {
		this.second = second;
	}

	public ArrayList<at.jumpandjan.Object> getThird() {
		return third;
	}

	public void setThird(ArrayList<at.jumpandjan.Object> third) {
		this.third = third;
	}

	public void render() {
		for (at.jumpandjan.Object o : first) {
			o.render();
		}
		for (at.jumpandjan.Object o : second) {
			if (((Entity) o).isAlive())
				o.render();
		}
		for (at.jumpandjan.Object o : second_point) {
			if (((Entity) o).isAlive())
				o.render();
		}
		for (at.jumpandjan.Object o : third) {
			if (((Entity) o).isAlive())
				o.render();
		}
	}

	public void update() {
		for (at.jumpandjan.Object o : deadObjects) {
			first.remove(o);
			second.remove(o);
			third.remove(o);
		}
		deadObjects.clear();
		for (at.jumpandjan.Object o : first) {
			o.update();
		}
		for (at.jumpandjan.Object o : second) {
			if (((Entity) o).isAlive())
				o.update();
		}
		for (at.jumpandjan.Object o : second_point) {
			if (((Entity) o).isAlive())
				o.update();
		}
		for (at.jumpandjan.Object o : third) {
			if (((Entity) o).isAlive())
				o.update();
		}
	}

	public EntityPlayer getPlayer() {
		return player;
	}

	public EntityStartFlag getStartFlag() {
		for (at.jumpandjan.Object o : first) {
			if (o instanceof EntityStartFlag) {
				return (EntityStartFlag) o;
			}
		}
		return null;
	}

	public ArrayList<at.jumpandjan.Object> getDeadObjects() {
		return deadObjects;
	}

	public Level(ArrayList<Object> first, ArrayList<Object> second,
			ArrayList<Object> third) {
		super();
		this.first = first;
		this.second = second;
		this.third = third;
	}

	static {
		Out.inf(Level.class, "23.10.12", "Felix, Michi", null);
	}
}

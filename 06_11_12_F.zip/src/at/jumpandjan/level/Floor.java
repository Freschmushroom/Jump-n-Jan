package at.jumpandjan.level;

import java.io.Serializable;

import at.freschmushroom.Out;

public class Floor implements Serializable, LevelElement {
	private int pos;
	private int length;
	private int height;

	public Floor(int pos, int length, int height) {
		this.pos = pos;
		this.length = length;
		this.height = height;
	}

	public int getPos() {
		return pos;
	}

	public int getLength() {
		return length;
	}

	public int getHeight() {
		return height;
	}

	@Override
	public at.jumpandjan.Object getElement(Level level) {
		return new at.jumpandjan.Floor(pos, height, length, 10, level);
	}
	
	static {
		Out.inf(Floor.class, "23.10.12", "Felix", null);
	}
}

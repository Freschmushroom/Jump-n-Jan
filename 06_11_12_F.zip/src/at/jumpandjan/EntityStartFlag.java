package at.jumpandjan;

import at.jumpandjan.level.Level;
import at.freschmushroom.Out;

public class EntityStartFlag extends EntityFlag {

	public EntityStartFlag(double x, Level level) {
		super(x, "/Start_Flag.png", level);
	}

	@Override
	public void update() {
		super.update();
	}

	static {
		Out.inf(EntityStartFlag.class, "23.10.12", "Felix", null);
	}
}

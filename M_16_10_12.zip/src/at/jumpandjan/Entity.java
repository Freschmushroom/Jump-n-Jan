package at.jumpandjan;

import java.util.ArrayList;

public class Entity extends Object {
	protected boolean state;
	protected ArrayList<Entity> collisions;

	public Entity(double x, double y, double width, double height) {
		super(x, y, width, height);
		collisions = new ArrayList<Entity>();
	}

	public void update() {
		if (motionX < 0)
			state = true;
		else if (motionX > 0)
			state = false;
		motionY += 1.4;
		collisions.clear();
		label1: for (int i = 0; i < 20000; i++) {
			double x = this.x + motionX * 0.00005;
			for (Object o : collision) {
				if (x >= o.x && x <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height || x >= o.x
						&& x <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height) {
					motionX = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label1;
				}
				if (o.x >= x && o.x <= x + width && o.y >= y
						&& o.y <= y + height || o.x + o.width >= x
						&& o.x + o.width <= x + width && o.y >= y
						&& o.y <= y + height || o.x + o.width >= x
						&& o.x + o.width <= x + width && o.y + o.height >= y
						&& o.y + o.height <= y + height || o.x >= x
						&& o.x <= x + width && o.y + o.height >= y
						&& o.y + o.height <= y + height) {
					motionX = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label1;
				}
			}
			this.x = x;
		}
		onGround = false;
		label2: for (int i = 0; i < 20000; i++) {
			double y = this.y + motionY * 0.00005;
			for (Object o : collision) {
				if (x >= o.x && x <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y >= o.y
						&& y <= o.y + o.height || x + width >= o.x
						&& x + width <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height || x >= o.x
						&& x <= o.x + o.width && y + height >= o.y
						&& y + height <= o.y + o.height) {
					if(motionY > 0)
						onGround = true;
					motionY = 0;
					if (o instanceof Entity)
						collisions.add((Entity) o);
					break label2;
				}
			}
			this.y = y;
		}
	}

	public double getPivotX() {
		return x + width / 2D;
	}

	public double getPivotY() {
		return y + height / 2D;
	}
}

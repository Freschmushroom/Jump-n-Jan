package at.jumpandjan;

public class EntityStartFlag extends EntityFlag {

	public EntityStartFlag(double x) {
		super(x, "/Start_Flag.png");
	}

	@Override
	public void update() {
		super.update();
	}

}

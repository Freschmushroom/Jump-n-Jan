package at.jumpandjan;

import static org.lwjgl.opengl.GL11.GL_QUADS;
import static org.lwjgl.opengl.GL11.GL_TEXTURE_2D;
import static org.lwjgl.opengl.GL11.glBegin;
import static org.lwjgl.opengl.GL11.glDisable;
import static org.lwjgl.opengl.GL11.glEnable;
import static org.lwjgl.opengl.GL11.glEnd;
import static org.lwjgl.opengl.GL11.glPopMatrix;
import static org.lwjgl.opengl.GL11.glPushMatrix;
import static org.lwjgl.opengl.GL11.glScalef;
import static org.lwjgl.opengl.GL11.glTexCoord2f;
import static org.lwjgl.opengl.GL11.glTranslated;
import static org.lwjgl.opengl.GL11.glVertex2d;

public class EntityPsy extends Entity {

	private int cdJump;
	private int cdAnimation;
	private int cdAttack;
	private boolean animState;

	public EntityPsy(double x, double y) {
		super(x, y, 32, 64);
	}

	@Override
	public void update() {
		super.update();
		this.motionX = 0;
		if (Math.abs(JumpAndJan.getPlayer().getPivotX() - this.getPivotX()) < 320
				&& Math.abs(JumpAndJan.getPlayer().getPivotX()
						- this.getPivotX()) > 1) {
			motionX = (JumpAndJan.getPlayer().getPivotX() - this.getPivotX())
					/ Math.abs(JumpAndJan.getPlayer().getPivotX()
							- this.getPivotX()) * 1.5f;
		}
		if (JumpAndJan.getPlayer().y + JumpAndJan.getPlayer().height < this.y
				&& onGround && JumpAndJan.getPlayer().onGround) {
			if (cdJump <= 0) {
				motionY = -20;
				cdJump = 10;
			} else
				cdJump--;
		}
		if (collisions.contains(JumpAndJan.getPlayer()) && cdAttack <= 0) {
			JumpAndJan.getPlayer().hurt(10);
			cdAttack = 120;
		}
		cdAttack--;
	}

	@Override
	public void render() {
		glPushMatrix();
		glTranslated(x, y, 0);
		if (animState) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		if (state) {
			glTranslated(width, 0, 0);
			glScalef(-1, 1, 1);
		}
		glEnable(GL_TEXTURE_2D);
		TextureManager.instance.bindTexture(TextureManager.instance
				.getTexture("/Opp_Psy.png"));
		float f = 1 / 32f;
		float f1 = 1 / 64f;
		glBegin(GL_QUADS);
		glTexCoord2f(0, 0);
		glVertex2d(0, 0);
		glTexCoord2f(0, 64 * f1);
		glVertex2d(0, height);
		glTexCoord2f(32 * f, 64 * f1);
		glVertex2d(width, height);
		glTexCoord2f(32 * f, 0);
		glVertex2d(width, 0);
		glEnd();
		glDisable(GL_TEXTURE_2D);
		glPopMatrix();
		if (cdAnimation == 0) {
			animState = !animState;
			cdAnimation = 10;
		}
		cdAnimation--;
	}

}

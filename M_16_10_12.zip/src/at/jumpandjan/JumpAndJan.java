package at.jumpandjan;

import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import org.lwjgl.*;
import org.lwjgl.input.*;
import org.lwjgl.openal.AL;
import org.lwjgl.opengl.*;
import org.lwjgl.opengl.DisplayMode;

import at.jumpandjan.audio.SoundContainer;
import at.jumpandjan.level.Level;
import at.jumpandjan.level.LevelBuilder;

import static org.lwjgl.opengl.GL11.*;

public class JumpAndJan {
	private static EntityPlayer player = new EntityPlayer(304, 330, 32, 64);
	private static Floor floor = new Floor(10, 460, 2000, 10);
	private static Floor plat1 = new Floor(300, 400, 620, 10);
	private static EntityStartFlag start = new EntityStartFlag(10);
	private static EntityFinishFlag finish = new EntityFinishFlag(1000);
	private static Wall wall1 = new Wall(20, 10, 10, 400);
	public static int DISPLAY_WIDTH;
	public static int DISPLAY_HEIGHT;
	public static boolean paused;
	public static boolean running = true;
	private static boolean music = true;
	private static Level actualLevel = null;

	public static void main(String[] args) {
		actualLevel = new Level(LevelBuilder.load("Level0.xml"));
		try {
			Frame f = new Frame("Jump\'n\'Jan");
			Canvas canvas = new Canvas();
			f.add(canvas);
			f.addFocusListener(new FocusListener() {

				@Override
				public void focusLost(FocusEvent e) {
					paused = true;
				}

				@Override
				public void focusGained(FocusEvent e) {
					paused = false;
				}
			});
			f.addWindowListener(new WindowListener() {

				@Override
				public void windowOpened(WindowEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void windowClosing(WindowEvent e) {
					((Frame) e.getSource()).dispose();
					running = false;
				}

				@Override
				public void windowClosed(WindowEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void windowIconified(WindowEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void windowDeiconified(WindowEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void windowActivated(WindowEvent e) {
					// TODO Auto-generated method stub

				}

				@Override
				public void windowDeactivated(WindowEvent e) {
					// TODO Auto-generated method stub

				}

			});
			f.setVisible(true);
			f.setSize(640 + f.getInsets().left + f.getInsets().right,
					480 + f.getInsets().top + f.getInsets().bottom);
			f.setLocationRelativeTo(null);
			f.requestFocus();
			Display.setTitle("Jump\'n\'Jan");
			Display.setDisplayMode(new DisplayMode(640, 480));
			Display.create();
			Display.setParent(canvas);
			f.requestFocus();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		SoundContainer.init();
		if (music)
			SoundContainer.startGameMusic();
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, 640, 480, 0, 1, -1);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glViewport(0, 0, 640, 480);

		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		/*
		 * EntityMeatball mb = new EntityMeatball(150, 300);
		 * mb.collision.add(floor); mb.collision.add(getPlayer());
		 * mb.collision.add(plat1); mb.collision.add(wall1);
		 * getPlayer().collision.add(mb); getPlayer().collision.add(floor);
		 * getPlayer().collision.add(plat1); getPlayer().collision.add(wall1);
		 * finish.collision.add(getPlayer());
		 */
		actualLevel.getStartFlag().spawn();
		getPlayer().x += 40;
		while (!Display.isCloseRequested() && running) {
			DISPLAY_WIDTH = Display.getWidth();
			DISPLAY_HEIGHT = Display.getHeight();
			glClearColor(0, 0, 1, 0);
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			glTranslated(-getPlayer().x + 304, 0, 0);
			/*
			 * getPlayer().render(); mb.render(); floor.render();
			 * plat1.render(); wall1.render(); finish.render(); start.render();
			 */
			actualLevel.render();
			if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
				getPlayer().motionX = -3;
			} else if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
				getPlayer().motionX = 3;
			} else
				getPlayer().motionX = 0;
			while (Keyboard.next()) {
				if (Keyboard.getEventKeyState()
						&& Keyboard.getEventKey() == Keyboard.KEY_SPACE
						&& getPlayer().onGround) {
					getPlayer().motionY -= 20;
				}
			}

			if (!paused) {
				/*
				 * getPlayer().update(); mb.update(); finish.update();
				 */
				actualLevel.update();
			}
			glLoadIdentity();
			glPushMatrix();
			glEnable(GL_TEXTURE_2D);
			TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/ProgressBar.png"));
			glBegin(GL_QUADS);
			glTexCoord2f(0, 0);
			glVertex2f(64, 10);
			glTexCoord2f(1, 0);
			glVertex2f(576, 10);
			glTexCoord2f(1, 1);
			glVertex2f(576, 18);
			glTexCoord2f(0, 1);
			glVertex2f(64, 18);
			glEnd();
			glDisable(GL_TEXTURE_2D);
			glPopMatrix();
			glPushMatrix();
			glEnable(GL_TEXTURE_2D);
			TextureManager.instance.bindTexture(TextureManager.instance.getTexture("/Progress.png"));
			float health = getPlayer().getHp() / 200F;
			float x2 = health * 504 + 69;
			glBegin(GL_QUADS);
			glTexCoord2f(0, 0);
			glVertex2f(69, 12);
			glTexCoord2f(1, 0);
			glVertex2f(x2, 12);
			glTexCoord2f(1, 1);
			glVertex2f(x2, 16);
			glTexCoord2f(0, 1);
			glVertex2f(69, 16);
			glEnd();
			glDisable(GL_TEXTURE_2D);
			glPopMatrix();
			Display.update();
			Display.sync(60);
		}
		AL.destroy();
		Display.destroy();
	}

	/*
	 * public static void main(String[] args) {
	 * 
	 * JumpAndJan jaj = new JumpAndJan(); SoundContainer.init(); if (music)
	 * SoundContainer.startGameMusic(); glMatrixMode(GL_PROJECTION);
	 * glLoadIdentity(); glOrtho(0, 640, 480, 0, 1, -1);
	 * glMatrixMode(GL_MODELVIEW); glLoadIdentity();
	 * 
	 * glViewport(0, 0, 640, 480);
	 * 
	 * glEnable(GL_TEXTURE_2D); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,
	 * GL_ONE_MINUS_SRC_ALPHA); jaj.start(); }
	 */

	public JumpAndJan() {
		Frame f = new Frame("Jump\'n\'Jan");
		Canvas canvas = new Canvas();
		f.add(canvas);
		f.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent e) {
				paused = true;
			}

			@Override
			public void focusGained(FocusEvent e) {
				paused = false;
			}
		});
		f.addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {
			}

			@Override
			public void windowClosing(WindowEvent e) {
				AL.destroy();
				Display.destroy();
				((Frame) e.getSource()).dispose();
				running = false;
			}

			@Override
			public void windowClosed(WindowEvent e) {
			}

			@Override
			public void windowIconified(WindowEvent e) {
			}

			@Override
			public void windowDeiconified(WindowEvent e) {
			}

			@Override
			public void windowActivated(WindowEvent e) {
			}

			@Override
			public void windowDeactivated(WindowEvent e) {
			}
		});
		f.setVisible(true);
		f.setSize(640 + f.getInsets().left + f.getInsets().right,
				480 + f.getInsets().top + f.getInsets().bottom);
		f.setLocationRelativeTo(null);
		f.requestFocus();
		try {
			Display.setTitle("Jump\'n\'Jan");
			Display.setDisplayMode(new DisplayMode(640, 480));
			Display.create();
			Display.setParent(canvas);
		} catch (LWJGLException e1) {
			e1.printStackTrace();
		}
		actualLevel = new Level(LevelBuilder.load("Level0.xml"));
	}

	public static EntityPlayer getPlayer() {
		return actualLevel.getPlayer();
	}

	public EntityPlayer getLevelPlayer() {
		return actualLevel != null ? actualLevel.getPlayer() : null;
	}

	public static void tooot() {
		running = false;
		SoundContainer.stopGameMusic();
		SoundContainer.gameOver.playAsSoundEffect(1, 1, true);
		while (true) {
			DISPLAY_WIDTH = Display.getWidth();
			DISPLAY_HEIGHT = Display.getHeight();
			glClearColor(1, 0, 0, 0);
			glClear(GL_COLOR_BUFFER_BIT);
			glLoadIdentity();
			glEnable(GL_TEXTURE_2D);
			FontRenderer.instance.drawStringAt("TOT", 10, 10, 630, 450,
					new float[] { 0, 1, 0 });
			glDisable(GL_TEXTURE_2D);
			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
				break;
			}
			Display.update();
			Display.sync(60);
		}
		try {
			AL.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
//		try {
//			Display.destroy();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}

	public class RenderThread extends Thread {
		public void run() {
			while (!Display.isCloseRequested() && running) {
				DISPLAY_WIDTH = Display.getWidth();
				DISPLAY_HEIGHT = Display.getHeight();
				glClearColor(0, 0, 1, 0);
				glClear(GL_COLOR_BUFFER_BIT);
				glLoadIdentity();
				glTranslated(-getPlayer().x + 304, 0, 0);
				actualLevel.render();
				if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
					getPlayer().motionX = -3;
				} else if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
					getPlayer().motionX = 3;
				} else
					getPlayer().motionX = 0;

				while (Keyboard.next()) {
					if (Keyboard.getEventKeyState()
							&& Keyboard.getEventKey() == Keyboard.KEY_SPACE
							&& getPlayer().onGround) {
						getPlayer().motionY -= 20;
					}
				}

				if (!paused) {
					actualLevel.update();
				}
				Display.update();
				Display.sync(60);
			}
			Display.destroy();
			System.exit(0);
		}
	}

	public void start() {
		new RenderThread().start();
	}
}

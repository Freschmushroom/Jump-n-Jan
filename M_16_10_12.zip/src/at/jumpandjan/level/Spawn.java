package at.jumpandjan.level;

import java.io.Serializable;

import at.jumpandjan.EntityMeatball;
import at.jumpandjan.EntityPsy;
import at.jumpandjan.EntityWaitrose;

public class Spawn implements Serializable, LevelElement {
	private int pos;
	private String type;
	private String kind;

	@Override
	public at.jumpandjan.Object getElement() {
		if (type.equals("opp") && kind.equals("meatball")) {
			return new EntityMeatball(pos, 320);
		} else if (type.equals("opp") && kind.equals("waitrose")) {
			return new EntityWaitrose(pos, 320);
		} else if (type.equals("opp") && kind.equals("psy")) {
			return new EntityPsy(pos, 320);
		}
		return null;
	}

	public int getPos() {
		return pos;
	}

	public String getType() {
		return type;
	}

	public String getKind() {
		return kind;
	}

	public Spawn(int pos, String type, String kind) {
		super();
		this.pos = pos;
		this.type = type;
		this.kind = kind;
	}

}

package at.jumpandjan.level;

import java.util.ArrayList;

import at.jumpandjan.EntityFinishFlag;
import at.jumpandjan.EntityPlayer;
import at.jumpandjan.EntityStartFlag;

public class Level {
	private int playerPos;
	private int start;
	private int finish;
	private String name;
	private int points;
	private ArrayList<at.jumpandjan.Object> first = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> second = new ArrayList<at.jumpandjan.Object>();
	private ArrayList<at.jumpandjan.Object> third = new ArrayList<at.jumpandjan.Object>();

	public Level(LevelBuilder lb) {
		playerPos = (start = lb.getStart());
		finish = lb.getFinish();
		name = lb.getName();
		for (LevelElement le : lb.getElements()) {
			if (le instanceof Wall || le instanceof Floor) {
				first.add(le.getElement());
			} else if (le instanceof Spawn) {
				second.add(le.getElement());
			}
		}
		first.add(new EntityStartFlag(start));
		first.add(new EntityFinishFlag(finish));
		third.add(new EntityPlayer(start, 100, 32, 64));
		for (at.jumpandjan.Object o : second) {
			for (at.jumpandjan.Object w : first) {
				o.collision.add(w);
			}
		}
		for (at.jumpandjan.Object o : first) {
			for (at.jumpandjan.Object w : third) {
				if(o instanceof EntityFinishFlag || o instanceof EntityStartFlag) {
					o.collision.add(w);
				} else {
					w.collision.add(o);
				}
			}
		}
		for (at.jumpandjan.Object o : second) {
			for (at.jumpandjan.Object w : third) {
				o.collision.add(w);
			}
		}
	}

	public int getPlayerPos() {
		return playerPos;
	}

	public void setPlayerPos(int playerPos) {
		this.playerPos = playerPos;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getFinish() {
		return finish;
	}

	public void setFinish(int finish) {
		this.finish = finish;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

	public ArrayList<at.jumpandjan.Object> getFirst() {
		return first;
	}

	public void setFirst(ArrayList<at.jumpandjan.Object> first) {
		this.first = first;
	}

	public ArrayList<at.jumpandjan.Object> getSecond() {
		return second;
	}

	public void setSecond(ArrayList<at.jumpandjan.Object> second) {
		this.second = second;
	}

	public ArrayList<at.jumpandjan.Object> getThird() {
		return third;
	}

	public void setThird(ArrayList<at.jumpandjan.Object> third) {
		this.third = third;
	}

	public void render() {
		for (at.jumpandjan.Object o : first) {
			o.render();
		}
		for (at.jumpandjan.Object o : second) {
			o.render();
		}
		for (at.jumpandjan.Object o : third) {
			o.render();
		}
	}

	public void update() {
		for (at.jumpandjan.Object o : first) {
			o.update();
		}
		for (at.jumpandjan.Object o : second) {
			o.update();
		}
		for (at.jumpandjan.Object o : third) {
			o.update();
		}
	}
	
	public EntityPlayer getPlayer() {
		for(at.jumpandjan.Object o : third) {
			if( o instanceof EntityPlayer) {
				return (EntityPlayer) o;
			}
		}
		return null;
	}
	public EntityStartFlag getStartFlag() {
		for(at.jumpandjan.Object o : first) {
			if( o instanceof EntityStartFlag) {
				return (EntityStartFlag) o;
			}
		}
		return null;
	}
}

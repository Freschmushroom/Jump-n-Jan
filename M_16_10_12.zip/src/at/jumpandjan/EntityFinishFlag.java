package at.jumpandjan;

public class EntityFinishFlag extends EntityFlag {
	public EntityFinishFlag(double x) {
		super(x, "/Finish_Flag.png");
	}

	@Override
	public void update() {
		super.update();
		if(collisions.contains(JumpAndJan.getPlayer())) {
			JumpAndJan.tooot();
		}
	}
}
